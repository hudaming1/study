package com.mytest;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qudian on 2017/7/28.
 */
public class Calc1 {

    private static List<Character> OP_LIST = new ArrayList<>();
    private static List<Character> NUMBER_LIST = new ArrayList<>();

    static {
        OP_LIST.add('+');
        OP_LIST.add('-');
        OP_LIST.add('*');
        OP_LIST.add('/');

        NUMBER_LIST.add('1');
        NUMBER_LIST.add('2');
        NUMBER_LIST.add('3');
        NUMBER_LIST.add('4');
        NUMBER_LIST.add('5');
        NUMBER_LIST.add('6');
        NUMBER_LIST.add('7');
        NUMBER_LIST.add('8');
        NUMBER_LIST.add('9');
        NUMBER_LIST.add('0');
    }

    public static void main(String args[]) {
        String input = "1+12*3";
        for (Character c: input.toCharArray()) {

        }
    }
}
