package com.mytest;

import java.util.*;

/**
 * Created by qudian on 2017/8/1.
 */
public class Tt {
    public static void main(String args[]) {
        Collection<String> jobIds = new HashSet<>();
        Random rand = new Random();
        jobIds.add("job_1");
        for (int i = 0 ;i < 50000;i ++) {
            String jobId = "job_" + i;
            jobIds.add(jobId);
        }

        List<String> waitRemove = new ArrayList<>();
        for (int i = 0 ;i < 40000;i ++) {
            String jobId = "job_" + i;
            waitRemove.add(jobId);
        }

        long start = System.currentTimeMillis();
        System.out.println("start");
        jobIds.removeAll(waitRemove);
        System.out.println("end:" + (System.currentTimeMillis() - start));
        System.out.println(jobIds.size());
    }

}
