package com.mytest;

import java.util.Arrays;

/**
 * 用一个数组,存储3个Stack,一个在表头,一个存在表尾,一个在中位
 */
public class Stack2 {

    static class Stack {

        private int length = 16;
        private int[] numbers = new int[length];

        private int cursor1 = 0;
        private int length1 = 0;

        private void validateIsFull() {
            if (length1 + length2 + length3 >= length) {
                throw new IndexOutOfBoundsException("too more elements");
            }
        }

        public void push1(int num) {
            validateIsFull();
            if (cursor1 >= start) {
                // 如果空间足够,但后面空间被stack3占用,则需要将stack3后移,然后再stack1入栈
                moveStack2After();
            }
            numbers[cursor1++] = num;
            length1 ++;
        }

        private void moveStack2After() {
            // 如果将stack3向后移动,需要判断后面元素是否被占用
            if (numbers[cursor3] != 0) { // 注意这里不用cursor3+1,因为cursor3指向的永远是stack3准备入栈的引用,而非最后一次使用的指针
                throw new RuntimeException("no enought space to allocate!");
            }
            System.out.println("move after");
            System.arraycopy(numbers, start, numbers, start + 1, length3);
            start ++;
            cursor3 ++;
        }

        private void moveStack2Before() {
            if (numbers[start - 1] != 0) {
                throw new RuntimeException("no enought space to allocate!");
            }
            System.out.println("move before");
            System.arraycopy(numbers, start, numbers, start - 1, length3);
            start --;
            cursor3 --;
        }

        public int pop1() {
            int num = numbers[--cursor1];
            numbers[cursor1] = 0;
            length1 --;
            return num;
        }

        private int cursor2 = length - 1;
        private int length2 = 0;
        public void push2(int num) {
            validateIsFull();
            // 如果末端Stack游标触碰到中间的stack,则需要将中间Stack向前移动,腾出空间
            if (cursor2 <= cursor3) {
                moveStack2Before();
            }
            numbers[cursor2--] = num;
            length2 ++;
        }

        public int pop2() {
            int num = numbers[++cursor2];
            numbers[cursor2] = 0;
            length2 --;
            return num;
        }

        public void printArray() {
            System.out.println(Arrays.toString(numbers));
        }

        private int start = 0;
        private int cursor3 = 0;
        private int length3 = 0;
        {
            // init cursor3
            cursor3 = length / 3;
            start = cursor3;
        }

        public void push3(int num) {
            validateIsFull();
            // 判断后面是否有空间,如果有的话,直接使用
            if (cursor3 > cursor2) {
                moveStack2Before();
            }
            numbers[cursor3 ++] = num;
            length3 ++;
        }

        public int pop3() {
            int num = numbers[--cursor3];
            numbers[cursor3] = 0;
            length3 --;
            return num;
        }
    }

    public static void main(String args[]) {
        Stack2.Stack stack = new Stack2.Stack();


        stack.push1(1);
        stack.push1(2);
        stack.push1(3);
        stack.push1(4);

        stack.push2(5);
        stack.push2(6);
        stack.push2(7);
        stack.push2(8);

        stack.printArray();

        stack.push3(11);
        stack.push3(12);
        stack.push3(13);
        stack.push3(14);
        stack.printArray();

        stack.push3(15);
        stack.push3(16);
        stack.push3(17);
        stack.push3(18);

        stack.printArray();
    }
}
