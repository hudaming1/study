package com.mytest;

/**
 * 使用双向循环链表实现队列
 */
public class StackQueue {
    static class Queue {

        private int length = 0;
        private Node header = null;
        private Node tail = null;

        public Queue() {}

        public void offer(Object o) {
            if (header == null) {
                header = new Node(o, header, header);
                tail = header;
                length ++;
                return;
            }
            Node newNode = new Node(o, header, tail);
            tail.next = newNode;
            tail = newNode;
            length ++;
        }

        public Object poll() {
            Object val = header.val;
            header.val = null;
            Node newHeader = header.next;
            newHeader.previous = tail;
            tail.next = newHeader;
            header = newHeader;
            length --;
            return val;
        }

        static class Node {
            public Object val;
            public Node next;
            public Node previous;
            public Node(Object val, Node next, Node previous) {
                this.val = val;
                this.next = next;
                this.previous = previous;
            }
        }

        public void printDatas() {
            String s = "";
            Node cursor = header;
            for (int i = 0 ;i < length;i ++) {
                s += cursor.val + ", ";
                cursor = cursor.next;
            }
            System.out.println(s);
        }
    }

    public static void main(String args[]) {
        Queue queue = new Queue();
        queue.offer(1);
        queue.offer(2);
        queue.offer(3);
        queue.offer(4);
        queue.offer(5);
        queue.offer(6);
        queue.offer(7);
        queue.offer(8);
        queue.printDatas();

        System.out.println("poll : " + queue.poll());
        queue.printDatas();
    }
}
