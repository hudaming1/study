package com.mytest;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class TreeTest2 {

    static Tree.TreeNode buildTree() {
        Tree.TreeNode node = Tree.buildTree();
        node.left.left.right = new Tree.TreeNode("8", null, null);
        return node;
    }

    /**
     * 写法简单,但个人感觉不容易理解.
     * @return
     */
    static int findMaxDeep(Tree.TreeNode node) {
        int l, r;
        if (node == null) {
            return 0;
        }
        l = findMaxDeep(node.left);
        r = findMaxDeep(node.right);
        return (l > r ? l : r) + 1;
    }

    /**
     * 根据自己理解
     *  @return deep代表所在level
     */
    static int findMaxDeep(Tree.TreeNode node, int deep) {
        if (node == null) {
            return deep;
        }
        deep ++;
        int left = findMaxDeep(node.left, deep);
        int right = findMaxDeep(node.right, deep);
        return left > right? left : right;
    }

    static int findMaxDeep2(Tree.TreeNode node) {
        int max = 0;

        Tree.TreeNode cursor = node;
        Queue<Tree.TreeNode> queue = new LinkedList<>();

        while (cursor != null) {
            System.out.println(cursor.value);
            queue.offer(cursor.left);
            queue.offer(cursor.right);
        }

        return max;
    }



    public static void main(String args[]) {
        Tree.TreeNode node = buildTree();
        System.out.println(findMaxDeep2(node));
    }
}
