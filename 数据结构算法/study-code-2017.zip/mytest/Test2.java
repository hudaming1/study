package com.mytest;

import java.util.*;

public class Test2 {

    private static Map<Character, Character> charsetMap = new HashMap<Character, Character>();

    static {
        charsetMap.put(')', '(');
        charsetMap.put('}', '{');
        charsetMap.put(']', '[');
    }

    public static void main(String args[]) {
        String inputStr1 = "{[(2+4)+(3-5)/9]*4+1}*{[(2-4)+(3-5)*9]*(4+1)}]";
        String inputStr2 = "{[1+2]}";
        String inputStr3 = "[[(1+2)}]";

        System.out.println(kuohao(inputStr1));
        System.out.println(kuohao(inputStr2));
        System.out.println(kuohao(inputStr3));
    }

    private static boolean kuohao(String inputStr1) {
        Stack<Character> stack = new Stack<>();
        for (char c : inputStr1.toCharArray()) {
            // 如果不匹配括号字符,则判断下一个字符
            if (!isMatch(c)) {
                continue;
            }
            // 如果匹配到开符号,则入栈
            if (isOpenChar(c)) {
                stack.push(c);
            } else if (isCloseChar(c) && stack.isEmpty()) {
                // 如果匹配到了闭符号,但Stack已经为空说明括号没有成对出现
                System.out.println("括号没有成对出现");
                return false;
            } else if (isCloseChar(c) && !stack.isEmpty()) {
                Character openChar = stack.peek();
                // 这里需要判断一下,栈顶的开符号和正在处于遍历的闭符号是否是成对(例如"("和"]"就不成对,这样不能算匹配)
                if (openChar != null && openChar.equals(charsetMap.get(c))) {
                    stack.pop();
                } else {
                    System.out.println("括号匹配错误");
                    // 如果不匹配,直接返回,不再后续判断了
                    return false;
                }
            }
        }
        return true;
    }

    private static boolean isOpenChar(char c) {
        return charsetMap.values().contains(c);
    }

    private static boolean isCloseChar(char c) {
        return charsetMap.keySet().contains(c);
    }

    private static boolean isMatch(char c) {
        return isOpenChar(c) || isCloseChar(c);
    }
}
