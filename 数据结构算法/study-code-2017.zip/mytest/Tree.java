package com.mytest;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

/**
 * Created by qudian on 2017/7/31.
 */
public class Tree {

    static class TreeNode {
        public Object value;
        public TreeNode left;
        public TreeNode right;
        public TreeNode() {}
        public TreeNode(Object value, TreeNode left, TreeNode right) {
            this.value = value;
            this.left = left;
            this.right = right;
        }

        @Override
        public String toString() {
            return "[TreeNode value=" + value + "]";
        }
    }

    static TreeNode buildTree() {
        TreeNode left = new TreeNode(2, new TreeNode(4, null, null), new TreeNode(5, null, null));
        TreeNode right = new TreeNode(3, new TreeNode(6, null, null), new TreeNode(7, null, null));
        return new TreeNode(1, left, right);
    }

    static void preOrder(TreeNode node) {
        if (node == null) {
            return ;
        }
        System.out.println(node.value);
        preOrder(node.left);
        preOrder(node.right);
    }

    static void preOrderUsingStack(TreeNode node) {
        TreeNode cursor = node;
        Stack<TreeNode> stack = new Stack<>();
        while (true) {
            while (cursor != null) {
                System.out.println(cursor.value);
                stack.push(cursor);
                cursor = cursor.left;
            }
            if (stack.isEmpty()) {
                break;
            }
            TreeNode n = stack.pop();
            cursor = n.right;
        }
    }

    static void middleOrder(TreeNode node) {
        if (node == null) {
            return;
        }
        afterOrder(node.left);
        System.out.println(node.value);
        afterOrder(node.right);
    }

    static void middleOrder2(TreeNode node) {
        TreeNode cursor = node;
        Stack<TreeNode> stack = new Stack<>();
        while (true) {
            while (cursor != null) {
                stack.push(cursor);
                cursor = cursor.left;
            }
            if (stack.isEmpty()) {
                break;
            }
            TreeNode n = stack.pop();
            System.out.println(n.value);
            cursor = n.right;
        }
    }

    static void afterOrder(TreeNode node) {
        if (node == null) {
            return;
        }
        afterOrder(node.right);
        System.out.println(node.value);
        afterOrder(node.left);
    }

    static void afterOrder2(TreeNode node) {
        TreeNode cursor = node;
        Stack<TreeNode> stack = new Stack<>();
        while (true) {
            while (cursor != null) {
                stack.push(cursor);
                cursor = cursor.right;
            }
            if (stack.isEmpty()) {
                break;
            }
            TreeNode n = stack.pop();
            System.out.println(n.value);
            cursor = n.left;
        }
    }

    static void levelOrder(TreeNode node) {
        TreeNode cursor = node;
        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(cursor);
        while (!queue.isEmpty()) {
            TreeNode n = queue.poll();
            System.out.println(n.value);

            if (n.left != null) {
                queue.offer(n.left);
            }
            if (n.right != null) {
                queue.offer(n.right);
            }
        }
    }

    static int findMax(TreeNode node) {
        if (node == null) {
            return Integer.MIN_VALUE;
        }
        Integer leftMax = findMax(node.left);
        Integer rightMax = findMax(node.right);

        return Math.max(Math.max((Integer) leftMax, (Integer) rightMax), (Integer) node.value);
    }

    public static void main(String args[]) {
        afterOrder(buildTree());
    }
}