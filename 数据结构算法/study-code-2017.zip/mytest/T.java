package com.mytest;

import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.TreeMap;

/**
 * Created by qudian on 2017/8/2.
 */
public class T {

    static int leaftCount(Tree.TreeNode node) {
        if (node == null) {
            return 0;
        }
        if (node.left == null && node.right == null) {
            System.out.println(node.value);
            return 1;
        }
        return leaftCount(node.left) + leaftCount(node.right);
    }

    public static void main(String args[]) {
        Tree.TreeNode node = Tree.buildTree();
        // node.left.right.left = new Tree.TreeNode();
        System.out.println(leaftCount(node));
    }
}
