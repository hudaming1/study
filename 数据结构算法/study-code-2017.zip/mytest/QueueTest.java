package com.mytest;

import java.util.Arrays;

/**
 * 循环数组实现Queue
 */
public class QueueTest {

    static class Queue<E> {

        private int ringSize = 8;
        private Object[] array = new Object[ringSize];
        private int header = 0;
        private int tail = 0;
        private final int start = 0 , end = ringSize - 1;
        private int length = 0;

        public void offer(E e) {
            // 如果容量不够,则需要进行扩容
            if (length >= ringSize) {
                return;
            } else if (tail > end) {
                // 当tail指针达到末端时,考虑复用start空间
                tail = start;
            }
            array[tail++] = e;
            length ++;
        }

        public void offer2(E e) {
            // 如果容量不够,则需要进行扩容
            if (length >= ringSize) {
                return;
            }
            array[tail % ringSize] = e;
            tail = (tail + 1) % ringSize ;
            length ++;
        }

        public E poll() {
            if (array.length <= 0) {
                return null;
            } else if (header > end) {
                header = start;
            }
            E e = (E) array[header];
            array[header] = null;
            header++;
            length--;
            return e;
        }

        public E poll2() {
            if (array.length <= 0) {
                return null;
            }
            E e = (E) array[header];
            array[header] = null;
            header = (header + 1) % ringSize;
            length--;
            return e;
        }

        public void printArray() {
            System.out.println(Arrays.toString(array));
        }
    }

    public static void main(String args[]) {
        QueueTest.Queue<Integer> queue = new QueueTest.Queue<>();
        queue.offer2(1);
        queue.offer2(2);
        queue.offer2(3);
        queue.offer2(4);
        queue.offer2(5);
        queue.offer2(6);
        queue.offer2(7);
        queue.offer2(8);
        queue.printArray();
        System.out.println("poll:" + queue.poll2());

        queue.printArray();
        // 明明还有一个空间可用,但offer失败,所以需要采用循环数组存储结构
        queue.offer2(9);
        queue.printArray();


        System.out.println("poll:" + queue.poll2());
        System.out.println("poll:" + queue.poll2());
        System.out.println("poll:" + queue.poll2());
        System.out.println("poll:" + queue.poll2());
        queue.printArray();
        System.out.println("poll:" + queue.poll());
        System.out.println("poll:" + queue.poll());
        System.out.println("poll:" + queue.poll());
        System.out.println("poll:" + queue.poll());
        queue.printArray();
        System.out.println("poll:" + queue.poll());
        queue.offer(1);
        queue.offer(2);
        queue.offer(3);
        queue.printArray();

    }
}
