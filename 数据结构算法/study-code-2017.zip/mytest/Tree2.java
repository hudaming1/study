package com.mytest;

import java.util.*;

/**
 * Created by qudian on 2017/8/4.
 */
public class Tree2 {

    static void levelOrder(Tree.TreeNode node) {
        Queue<Tree.TreeNode> queue = new LinkedList<>();
        while (node != null) {
            System.out.print(node.value);

            if (node.left != null)
                queue.offer(node.left);
            if (node.right != null)
                queue.offer(node.right);

            node = queue.poll();
        }
    }

    /**
     * 倒序层次遍历输出节点
     * 采用正序遍历的同时,将节点入栈,当遍历完成时,开始进行出栈.
     */
    static void reverseLevelOrder(Tree.TreeNode node) {
        Queue<Tree.TreeNode> queue = new LinkedList<>();
        Stack<Tree.TreeNode> stack = new Stack<>();
        while (node != null) {
            stack.push(node);

            if (node.left != null)
                queue.offer(node.left);
            if (node.right != null)
                queue.offer(node.right);

            node = queue.poll();
        }

        while (!stack.isEmpty()) {
            System.out.println(stack.pop().value);
        }
    }

    /**
     * 递归方式求Tree的高度
     */
    static int height(Tree.TreeNode node) {
        if (node == null) {
            return 0;
        }
        int left = height(node.left) + 1;
        int right = height(node.right) + 1;
        return left > right ? left : right;
    }

    /**
     * 非递归方式求树的高度
     */
    static int height2(Tree.TreeNode node) {
        // 写不出来
        return 0;
    }

    /**
     * 查找最深节点
     * 思路:按照层次遍历从上往下找,在queue为空时的前一个元素,应该就是最下层元素.
     */
    static Tree.TreeNode findDeepestNode(Tree.TreeNode node) {
        Queue<Tree.TreeNode> queue = new LinkedList<>();
        Tree.TreeNode cursor = node;
        queue.offer(cursor);
        while (!queue.isEmpty()) {
            cursor = queue.poll();
            if (cursor.left != null) {
                queue.offer(cursor.left);
            }
            if (cursor.right != null) {
                queue.offer(cursor.right);
            }
        }
        return cursor;
    }

    /**
     * 统计叶节点个数
     */
    static int leafNodeCount(Tree.TreeNode node) {
        if (node == null) {
            return 0;
        } else if (node.left == null && node.right == null) {
            return 1;
        }
        return leafNodeCount(node.left) + leafNodeCount(node.right);
    }

    /**
     * 统计叶节点个数(非递归)
     *
     * @param node
     * @return
     */
    static int leafNodeCount2(Tree.TreeNode node) {
        int count = 0;
        Tree.TreeNode cursor = node;
        Stack<Tree.TreeNode> stack = new Stack<>();

        while (true) {
            while (cursor != null) {
                if (cursor.left == null && cursor.right == null) {
                    count++;
                }
                stack.push(cursor);
                cursor = cursor.left;
            }
            if (stack.isEmpty()) {
                break;
            }
            cursor = stack.pop();
            cursor = cursor.right;
        }
        return count;
    }

    /**
     * 判断两个Tree是否完全一样
     */
    static boolean isSameTree(Tree.TreeNode node1, Tree.TreeNode node2) {
        if (node1 == null && node2 == null) {
            return true;
        } else if ((node1 == null && node2 != null) || (node1 != null && node2 == null)) {
            return false;
        } else if (node1.value != node2.value) {
            return false;
        }
        return isSameTree(node1.left, node2.left) && isSameTree(node1.right, node2.right);
    }

    /**
     * 计算整棵树所有节点值的总和
     */
    static int sumAllNodeValue(Tree.TreeNode node) {
        if (node == null) {
            return 0;
        }
        return sumAllNodeValue(node.left) + sumAllNodeValue(node.right) + (int) node.value;
    }

    /**
     * 求树的宽度(节点最多一层,左右两个节点之间的节点数量)
     * 使用队列结果+层次遍历方式可以很容易从上到下遍历一遍节点,但难点在于无法取分当前遍历处于第几层.
     * 需要一个变量记录,当入队次数等于出队次数时,认为本层遍历完成.
     *
     * @param node
     * @return
     */
    static int width(Tree.TreeNode node) {
        int max = 0;
        Queue<Tree.TreeNode> queue = new LinkedList<>();
        Tree.TreeNode cursor = node;
        int length = 0; // 记录本层节点数
        queue.offer(cursor);
        while (!queue.isEmpty()) {
            length = queue.size();
            while (length > 0) {
                cursor = queue.poll();
                length--;
                System.out.println(cursor.value);
                if (cursor.left != null) {
                    queue.offer(cursor.left);
                }
                if (cursor.right != null) {
                    queue.offer(cursor.right);
                }
            }
            max = Math.max(max, queue.size());
        }

        return max;
    }

    /**
     * 找出同一层节点之和最大的层
     * 和求树的宽度同理,把记录节点换成记录sum值即可
     */
    static int findValueMaxLevel(Tree.TreeNode node) {
        Queue<Tree.TreeNode> queue = new LinkedList<>();
        Tree.TreeNode cursor = node;
        int length = 0;
        int maxValue = 0;
        queue.offer(node);
        while (!queue.isEmpty()) {
            length = queue.size();
            int levelMaxValue = 0;
            while (length > 0) {
                cursor = queue.poll();
                levelMaxValue += (int) cursor.value;
                length--;
                if (cursor.left != null) {
                    queue.offer(cursor.left);
                }
                if (cursor.right != null) {
                    queue.offer(cursor.right);
                }
            }
            maxValue = Math.max(maxValue, levelMaxValue);
        }

        return maxValue;
    }

    /**
     * 输出根节点到所有叶子节点间的路径
     * 先序遍历,然后用queue记录经过路径即可.
     */
    static void printRootPath(Tree.TreeNode node, Queue<Tree.TreeNode> trace) {
        if (node == null) {
            return;
        }
        // 打印node节点路径
        print(new LinkedList<>(trace), node);

        Queue<Tree.TreeNode> newQueue = new LinkedList<>(trace);
        newQueue.offer(node);

        printRootPath(node.left, newQueue);
        printRootPath(node.right, newQueue);
    }

    static void print(Queue<Tree.TreeNode> trace, Tree.TreeNode node) {
        while (!trace.isEmpty()) {
            System.out.print(trace.poll().value);
        }
        System.out.println(node.value);

    }

    static void printRootPath(Tree.TreeNode node) {
        printRootPath(node, new LinkedList<>());
    }

    /**
     * 给定一个value,判断是否存在从根到任意节点经过路径值的总和等于这个value
     */
    static boolean findSumExpectValue(int expectValue, Tree.TreeNode node, int[] path, int length) {
        if (node == null) {
            return false;
        }

        int[] path2 = Arrays.copyOf(path, path.length);

        // process
        if (sum(path, node) == expectValue) {
            return true;
        }

        // append node to path
        path2[length++] = (int) node.value;

        return findSumExpectValue(expectValue, node.left, path2, length) || findSumExpectValue(expectValue, node.right, path2, length);
    }

    static int sum(int[] arr, Tree.TreeNode node) {
        int sum = 0;
        for (int num : arr) {
            if (num == 0) {
                break;
            }
            sum += num;
        }
        return sum + (int) node.value;
    }

    static boolean findSumExpectValue(int expectValue, Tree.TreeNode node) {
        return findSumExpectValue(expectValue, node, new int[256], 0);
    }

    /**
     * 写法2,一边遍历一边累加
     */
    static boolean findSumExpectValue2(Tree.TreeNode node, int expect, int pathNum) {
        if (node == null) {
            return false;
        }
        pathNum += (int) node.value;
        if (pathNum == expect) {
            return true;
        }
        return findSumExpectValue2(node.left, expect, pathNum) || findSumExpectValue2(node.right, expect, pathNum);
    }

    /**
     * 写法3:
     */
    static boolean findSumExpectValue3(Tree.TreeNode node, int expect) {
        if (node == null) {
            return expect == 0;
        }
        expect = expect - (int) node.value;
        if (expect == 0) {
            return true;
        }
        return findSumExpectValue3(node.left, expect) || findSumExpectValue3(node.right, expect);
    }

    /**
     * 获得二叉树某层的节点数
     */
    static int getLevelNodeCount(Tree.TreeNode node, int level) {
        int currentLevel = 1;
        Queue<Tree.TreeNode> queue = new ArrayDeque<>();
        queue.offer(node);
        while (!queue.isEmpty()) {
            int length = queue.size();
            if (currentLevel == level) {
                return queue.size();
            }
            while (length > 0) {
                node = queue.poll();
                length--;
                if (node.left != null) {
                    queue.offer(node.left);
                }
                if (node.right != null) {
                    queue.offer(node.right);
                }
            }
            currentLevel++;
        }
        return 0;
    }

    /**
     * 统计二叉树某层的节点数(递归算法)
     */
    static int getLevelNodeCount2(Tree.TreeNode node, int level) {
        if (node == null || level == 0) {
            return 0;
        } else if (level == 1) {
            return 1;
        }
        return getLevelNodeCount2(node.left, level - 1) + getLevelNodeCount2(node.right, level - 1);
    }

    /**
     * 二叉树中两个节点之间的路径
     */
    static List<Tree.TreeNode> findNoePath(Tree.TreeNode root, Tree.TreeNode node1, Tree.TreeNode node2) {

        Stack<Tree.TreeNode> path1 = new Stack<>();
        Tree.TreeNode findNode1 = findNode(root, node1, path1);
        System.out.println(path1);

        Stack<Tree.TreeNode> path2 = new Stack<>();
        Tree.TreeNode findNode2 = findNode(root, node2, path2);
        System.out.println(path2);

        return null;
    }

    static Tree.TreeNode findNode(Tree.TreeNode node, Tree.TreeNode goalNode, Stack<Tree.TreeNode> path) {
        if (node == null) {
            return null;
        } else if (node.value == goalNode.value) {
            path.push(node);
            return node;
        }
        path.push(node);
        Tree.TreeNode left = findNode(node.left, goalNode, path);
        if (left != null) {
            return left;
        }
        return findNode(node.right, goalNode, path);
    }

    /**
     * 二叉树两个节点之间的距离
     * @param args
     */

    /**
     * 二叉树中两个节点最近的公共父节点
     * @param args
     */

    /**
     * 求二叉树最大距离
     * 二叉树中任意两个节点都有且仅有一条路径，这个路径的长度叫这两个节点的距离。二叉树中所有节点之间的距离的最大值就是二叉树的直径。
     */
    static int getMaxDistance(Tree.TreeNode node) {
        return 0;
    }

    /**
     * 翻转二叉树
     * @param args
     */

    /**
     * 判断二叉树是否完全二叉树
     * @param args
     */

    /**
     * 判断二叉树是否满二叉树
     * @param args
     */

    /**
     * 判断二叉树是否平衡二叉树
     * @param args
     */

    public static void main(String args[]) {
        Tree.TreeNode node1 = Tree.buildTree();
        node1.right.left.left = new Tree.TreeNode(8, new Tree.TreeNode(9, null, null), new Tree.TreeNode(33, null, null));

        findNoePath(node1, new Tree.TreeNode(7, null, null), new Tree.TreeNode(4, null, null));
    }
}
