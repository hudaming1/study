package com.mytest;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import java.util.regex.Pattern;

/**
 * Created by qudian on 2017/7/28.
 */
public class SuffixExpTest {

    private static List<String> OP_LIST = new ArrayList<>();

    static {
        OP_LIST.add("+");
        OP_LIST.add("-");
        OP_LIST.add("*");
        OP_LIST.add("/");
    }

    public static void main(String args[]) {
        String exp = "3 4 + 5 × 6 -";
    }

    public static Integer suffixExp(String input) {
        Integer result = 0;
        Stack<Integer> numberStack = new Stack<>();
        Stack<String> opStack = new Stack<>();

        /**
         * 根据Stack进行计算(以"3 4 + 5 × 6 -"为例)
         *  (1) 从左至右扫描，将3和4压入堆栈；
         *  (2) 遇到+运算符，因此弹出4和3（4为栈顶元素，3为次顶元素，注意与前缀表达式做比较），计算出3+4的值，得7，再将7入栈；
         *  (3) 将5入栈；
         *  (4) 接下来是×运算符，因此弹出5和7，计算出7×5=35，将35入栈；
         *  (5) 将6入栈；
         *  (6) 最后是-运算符，计算出35-6的值，即29，由此得出最终结果。
         */
        for (String s : input.split(" ")) {
            if (isNumber(s)) {
                numberStack.push(Integer.parseInt(s));
            } else if (isOperator(s)) {
                opStack.push(s);
            }
        }

        return result;
    }

    private static boolean isOperator(String str) {
        return OP_LIST.contains(str);
    }

    private static Pattern pattern = Pattern.compile("[0-9]*");

    private static boolean isNumber(String str) {
        return pattern.matcher(str).matches();
    }
}
