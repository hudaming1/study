package com.mytest;

/**
 * Created by qudian on 2017/8/2.
 */
public class RecursionTest {

    /**
     * 计算num是几位数字
     */
    static int calcNumberBit(int num) {
        if (num / 10 == 0)
            return 1;
        return calcNumberBit(num / 10) + 1;
    }

    /**
     * 求阶乘
     */
    static int jc(int n) {
        if (n == 1) {
            return 1;
        }
        int result = jc(n - 1);
        return n * result;
    }

    /**
     * 放在银行里1W块钱,年利率为0.5%,求存N年后本息多钱
     */
    static float bankSalary(int year) {
        if (year == 0) {
            return 10000;
        }
        return bankSalary(year - 1) * 1.05f;
    }

    /**
     * 一张纸的厚度大约是0.08mm，对折多少次之后能达到珠穆朗玛峰的高度（8848.13米）？
     */
    static int zhezhi(float paper) {
        System.out.println(paper);
        if (paper >= 8848130) {
            return 0;
        }
        return zhezhi(paper * 2) + 1;
    }

    /**
     * 斐波那契数列
     */
    static int fbnq(int n) {
        if (n == 1) {
            return 1;
        } else if (n == 0) {
            return 0;
        }
        return fbnq(n - 1) + fbnq(n - 2);
    }

    private static int feibonaqie(int n) {
        // 循环+指针思想
        int result = 0;
        // 使用num1和num2永远指向result之前的2个数
        int num1 = 0;
        int num2 = 1;
        for (int i = 1; i < n; i++) {
            result = num1 + num2;
            num1 = num2;
            num2 = result;
        }
        return result;
    }

    /**
     * 打印出999以内所有的 "水仙花数 "，所谓 "水仙花数 "是指一个三位数，其各位数字立方和等于该数本身。
     * 　例如：153是一个 "水仙花数 "，因为153=1的三次方＋5的三次方＋3的三次方。
     */
    static int calcSxhs(int num) {
        // 该方法虽然看似用了递归,但却没有用到递归的思想,不过是在使用循环的思想搭配上了递归的写法
        if (num < 10) {
            return num * num * num;
        }
        return calcSxhs(num / 100) + calcSxhs(num % 100 / 10) + calcSxhs(num % 10);
    }

    /**
     * 水仙花数递归思考方式:
     * 1.知道需要计算这3组表达式(1*1*1 + 5*5*5 + 3*3*3),但顺序是怎样的,最后计算calc(3)还是calc(1)呢?确定了这个,就确定了递的执行顺序.
     * 仔细思考一下可知:因为只是做了加法运算,所以顺序不会影响计算结果,因此怎么好做就怎么写吧,得出递归调用代码为 calc(num / 10),
     * 这样calc(153)的执行过程就成了 calc(153) -> calc(15) -> calc(1)
     * 2.最小问题求解思路:考虑递归如何结束(如何衡量最小问题),以及如何解决最小的问题(即最后退出递归时的return结果),换言之就是在求解下面代码:
     * 首先考虑,如何衡量最小问题,递归153,过程为153->15->1,那么最小的问题就是当参数为个位数时,即化解到最小问题.
     * 其次考虑,calc(1) 经过什么样的计算,结果需要返回1*1*1,这里直接返回即可.
     * 3.在归途中合并结果:
     * calc(153) = calc(15) + x?
     * calc(15) = calc(1) + x?
     * calc(1) = n * n * n; (在第2步已确定)
     * calc(1) 已有答案,尝试求解calc(15),我们期望calc(15) = 1*1*1 + 5*5*5,由此看出前半部分1*1*1已经由calc(1)计算得出,而calc(15)
     * 函数除了调用calc(1)意外,还需要独立计算出5*5*5,并将计算结果与calc(1)的相加,由此得出:
     * int tmp = num % 10
     * int current = tmp * tmp * tmp;
     * return calc(n / 10) + current;
     *
     * @param num
     * @return
     */
    static int calcSxhs2(int num) {
        if (num < 10) {
            return num * num * num;
        }
        int tmp = num % 10;
        return calcSxhs2(num / 10) + tmp * tmp * tmp;
    }

    static void printSxhs(int num) {
        if (num > 999 || num < 100) {
            return;
        }
        if (calcSxhs2(num) == num) {
            System.out.println(num + " 是水仙花数");
        }
        printSxhs(num + 1);
    }

    /**
     * 5文钱可以买一只公鸡，3文钱可以买一只母鸡，1文钱可以买3只雏鸡。
     * 现在用100文钱买100只鸡，那么各有公鸡、母鸡、雏鸡多少只？请编写程序实现。
     */

    /**
     * 次用递归打印三角形
     */

    /**
     * 输出九九乘法表
     */
    static void chengfabiao(int num) {
        if (num > 9) {
            return;
        }
        chengfabiao_(1, num);
        System.out.println();
        chengfabiao(num + 1);
    }

    static void chengfabiao_(int base, int num) {
        if (base > num) {
            return;
        }
        System.out.print(base + " * " + num + " = " + (base * num) + "\t");
        chengfabiao_(base + 1, num);
    }

    /**
     * 猴子第一天摘下若干个桃子，当即吃了一半，还不过瘾，又多吃了一个，
     * 第二天早上又将剩下的桃子吃掉一半，又多吃了一个。以后每天早上都吃前一天剩下的一半零一个。
     * 到第n天早上想再吃时，见只剩下一个桃子了。求第一天共摘多少个桃子？
     */
    static int chitao(int days) {
        if (days == 1) {
            return 1;
        }
        return chitao(days - 1) * 2 + 2; // 为什么是加2呢?因为每天除了吃一半意外,还多吃一个,还剩一个
    }

    /**
     * 递归方式判断是否是回文字符
     * 在脑海中构建出判断方式,以level为例
     * 从外向里拆解问题,例如先对比最左边和最右边的两个字符,如果不相等则认为不是回文字符;如果相等的话,则继续向里靠拢,在靠拢前
     * 要先简化问题(即剥掉两边字符串),直到简化到最小问题时,有2种可能(
     * 1.最小的问题仅剩1个字符时,这时候认为是回文字符
     * 2.最小问题字符串为0,说明也是回文字符
     * )
     * <p>
     * 本题解决思路和吃桃等问题不同之处在于,在退出归路不需要合并计算结果,因为在递到最后时已经求解完成.
     */
    static boolean isCircleWord(String s) {
        if (s.length() <= 1) {
            return true;
        }
        char left = s.charAt(0);
        char right = s.charAt(s.length() - 1);
        if (left != right) {
            return false;
        }
        return isCircleWord(s.substring(1, s.length() - 1));
    }

    /**
     * 使用递归翻转字符串,本题求解思路和上面判断会问字符差不多
     */
    static void reverseChars(char[] str, int left, int right) {
        if (left >= right) {
            return;
        }
        char tmp = str[left];
        str[left] = str[right];
        str[right] = tmp;
        reverseChars(str, left + 1, right - 1);
    }

    /**
     * 折半查找
     * 1.递的路径
     * 2.退出条件:命中||找到最后一个元素
     *
     * 每次都查找数组中间位置的元素,然后与期望值进行比较;因为不能对数组进行操作(例如截断),因此需要增加高位地位指针来模拟数组被截断.
     */
    static boolean findNum(int[] nums, int left, int right, int expect) {
        int mid = (right + left) / 2; // 找中点的一个技巧,(地位+高位)/2;切忌用(高位-地位)/2
        if (left > right) {
            return false;
        } else if (nums[mid] == expect) {
            return true;
        } else if (nums[mid] < expect) {
            return findNum(nums, mid + 1, right, expect);
        } else {
            return findNum(nums, left, mid - 1, expect);
        }
    }

    static boolean findNum(int[] nums, int expect) {
        return findNum(nums, 0, nums.length - 1, expect);
    }

    /**
     * 简化问题:
     *  1.先向办法找到终止条件,输出
     *      abc/bac/cba
     */
    public static void permutation(char[] s,int from,int to) {
        if(to <= 1)
            return;
        if(from == to) {
            System.out.println(s);
        } else {
            for(int i=from; i<=to; i++) {
                swap(s,i,from); //交换前缀，使其产生下一个前缀
                permutation(s, from+1, to);
                swap(s,from,i); //将前缀换回，继续做上一个前缀的排列
            }
        }
    }

    static void pailie(char[] s, int index1, int index2) {
        // 暂时自己写不出来
    }

    static void swap(char[] str, int low, int high) {
        char c = str[low];
        str[low] = str[high];
        str[high] = c;
    }

    public static void main(String args[]) {
        pailie("abc".toCharArray(), 0, 2);
    }
}
