package com.mytest;

/**
 * Created by qudian on 2017/7/31.
 */
public class Test3 {

    static Integer maxGongyue(Integer... nums) {
        int max = 1;
        int minNumber = Integer.MAX_VALUE;
        for (Integer num : nums) {
            if (num < minNumber) {
                minNumber = num;
            }
        }
        for1:
        for (int i = 1; i <= minNumber; i++) {
            for (int j = 0; j < nums.length; j++) {
                if (nums[j] % i != 0) {
                    continue for1;
                } else if (nums[j] % i == 0 && j == nums.length - 1) {
                    max = i;
                }
            }
        }

        return max;
    }

    /**
     * 它根据递推策略设计的，求解效率更高
     */
    static Integer maxGongyue2(int a, int b) {

        int c = a % b;
        while (c != 0) {
            a = b;
            b = c;
            c = a % b;
        }
        return b;
    }

    /**
     * 两数中的大数减小数，其差与减数再进行大数减小数，
     * 直到差与减数相等为止，此时的差或者减数就是最大公约数。
     */
    static Integer maxGongyue3(int a, int b) {
        int c = a - b;

        return c;
    }

    /**
     * 求最小公倍数:
     *  公倍数,即几个数公共的倍数,例如25和40,公共倍数有180,360,720等,而180为最小公倍数.
     *
     *  最小公倍数,最小也是较大数字的整倍数,例如25和40,那么在求两个数的公倍数时,肯定是40/80/120/160/200这么算.
     */
    static Integer minGongbei(int a, int b) {
        return a * b / maxGongyue2(a, b);
    }

    static Integer gongyue(int a, int b) {
        int c = 1;

        // 如果a小于b,则交换2个变量值,来确保a>b
        if (a < b) {
            a = a + b;
            b = a - b;
            a = a - b;
        }

        do {
            c = a % b;
            a = b;
            // 如果c等于0,则说明已经除尽,则除数b为最大公约数
            if (c != 0) {
                b = c;
            }
        } while (c != 0);

        return b;
    }

    public static void main(String args[]) {
        System.out.println(gongyue(39 ,30));
    }
}