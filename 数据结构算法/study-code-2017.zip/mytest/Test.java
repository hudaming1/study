package com.mytest;

import java.util.LinkedList;

/**
 * Created by qudian on 2017/7/28.
 */
public class Test {
    public static void main(String[] args) {
        // 测试字符串，第一个匹配，第二个不匹配
        String inputStr1 = "{[(2+4)+(3-5)/9]*4+1}*{[(2-4)+(3-5)*9]*(4+1)}";
        String inputStr2 = "{[[2+4)+(3-5)/9]*4+1}*{[(2-4)+(3-5)*9]*(4+1)}";

        System.out.println(match(inputStr1) + "..." + match(inputStr2));
    }

    public static boolean match(String inputStr) {
        int len = inputStr.length();
        LinkedList<Character> stack = new LinkedList<Character>();
        // 循环遍历字符串
        for (int i = 0; i < len; i++) {
            // 如果是左括号则入栈
            if (isLeftBracket(inputStr.charAt(i))) {
                stack.push(inputStr.charAt(i));
                // 如果是右括号
            } else if (isRightBracket(inputStr.charAt(i))) {
                // 栈空，则右括号没有匹配的左括号，则返回false
                if (stack.isEmpty()) {
                    return false;
                    // 栈不空，则和栈顶比较
                } else if (stack.peek().equals(inputStr.charAt(i))) {
                    return false;
                } else {
                    stack.pop();
                }
            }
        }
        // 循环结束后，栈空表示匹配完了，不空表示多余左括号
        if (stack.isEmpty()) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 判断字符是不是左括号
     *
     * @param ch
     * @return
     */
    public static boolean isLeftBracket(char ch) {
        if (ch == '(' || ch == '[' || ch == '{') {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 判断字符是不是右括号
     *
     * @param ch
     * @return
     */
    public static boolean isRightBracket(char ch) {
        if (ch == ')' || ch == ']' || ch == '}') {
            return true;
        } else {
            return false;
        }
    }
}
