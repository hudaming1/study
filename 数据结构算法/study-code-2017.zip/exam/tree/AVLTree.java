package com.exam.tree;

import java.util.Stack;

/**
 * Created by qudian on 2017/8/11.
 */
class AVLNode {
    public int height = 0;
    public Integer value;
    public AVLNode left;
    public AVLNode right;
    public AVLNode() {}
    public AVLNode(int value, int height) {
        this.value = value;
        this.height = height;
    }
    public String toString() {
        return "[AVLNode value=" + value + ", height=" + height + "]";
    }
}
public class AVLTree {
    private AVLNode root;

    public AVLTree() { }

    public AVLTree(AVLTree.LinkedListNode node) {
        // 通过双向循环链表快速构造AVL树
        node.prev.next = null;
        node.prev = null;
        // 如果是循环链表是无法构造AVL树,所以现将循环结构打破
        this.root = buildAVLTree(node);
    }

    private AVLNode buildAVLTree(LinkedListNode node) {
        if (node == null) {
            return null;
        } else if (node.next == null) {
            return new AVLNode(node.value, 1);
        }
        AVLNode root = new AVLNode();
        LinkedListNode middleNode = LinkedListNode.getMiddleNode(node);
        if (middleNode.prev != null) {
            middleNode.prev.next = null;
        }
        if (middleNode.next != null) {
            middleNode.next.prev = null;
        }
        root.value = middleNode.value;
        root.left = buildAVLTree(LinkedListNode.getHeader(middleNode));
        root.right = buildAVLTree(middleNode.next);
        root.height = Math.max(height(root.left), height(root.right)) + 1;
        return root;
    }

    public void insert(int value) {
        root = insert(root, value);
    }

    private int height(AVLNode node) {
        return node == null ? 0 : node.height;
    }

    private AVLNode lr(AVLNode node) {
        node.left =  rr(node.left);
        return ll(node);
    }

    private AVLNode rl(AVLNode node) {
        node.right = ll(node.right);
        return rr(node);
    }

    private AVLNode ll(AVLNode node) {
        AVLNode newRoot = node.left;
        node.left = newRoot.right;
        newRoot.right = node;

        node.height = Math.max(height(node.left), height(node.right)) + 1;
        newRoot.height = Math.max(height(newRoot.left), height(newRoot.right)) + 1;

        return newRoot;
    }
    
    private AVLNode rr(AVLNode node) {
        AVLNode newRoot = node.right;
        node.right = newRoot.left;
        newRoot.left = node;

        node.height = Math.max(height(node.left), height(node.right)) + 1;
        newRoot.height = Math.max(height(newRoot.left), height(newRoot.right)) + 1;

        return newRoot;
    }

    /**
     * <pre>
     *	插入流程：
     *	 1.判断新节点插入位置：如果new_value小于current_node，则插入左子节点；反之插入到右子节点
     *	 2.递归查找到叶子节点，并插入新的节点
     *	 3.判断整棵Tree是否平衡，如不平衡则开始递归进行旋转
     *	 4.递归计算节点的高度
     * </pre>
     * <pre>
     * 	单侧旋转：
     * 	  LL（新插入节点val-12）		RR（新插入节点val-180）
     *      		100							100
     *	    	   /   \						   /   \
     *		  50   140					  50	   140
     *		 /  \						 	   /	  \
     *      30   70							 120	  160
     *     /											 \
     *    12 										 180
     *  双侧旋转：
     *  	  LR（新插入节点val-80）		RL（新插入节点val-110）
     *       	100							100
     *	    	   /   \						   /   \
     *		  50   140					  50	   140
     *		 /  \						 	   /	  \
     *      30   70							 120	  160
     *     		   \							 /		 
     *     			80					   110		 
     *   		
     * </pre>
     * <pre>
     * 	关于旋转：
     * 	  LL：左升根，根降右(var newRoot = node.left; node.left = newRoot.right; newRoot.right = node;)
     * 	  RR：右升根，根降左(var newRoot = node.right; node.right = newRoot.left; newRoot.left = node;)
     * 	  LR：右旋左子，左选自己(node.left = RR(node.left); node = LL(node);)
     * 	  RL：左选右子，右旋自己(node.right = LL(node.right); node = RR(node);)
     * </pre>
     * @param node
     * @param value
     * @return 
     */
    private AVLNode insert(AVLNode node, int value) {
        if (node == null) {
            return new AVLNode(value, 1);
        }
        // 如果插入值，小于当前节点，则在left节点找到一个合适位置
        if (value < node.value) {
            node.left = insert(node.left, value);
            if (height(node.left) - height(node.right) == 2) {
                if (value < node.left.value) {
                    // ll
                    node = ll(node);
                } else {
                    // lr
                    node = lr(node);
                }
            }
        } else if (value > node.value) {
            node.right = insert(node.right, value);
            if (height(node.right) - height(node.left) == 2) {
                if (value > node.right.value) {
                    // rr
                    node = rr(node);
                } else {
                    // rl
                    node = rl(node);
                }
            }
        } else if (value == node.value) {
            throw new RuntimeException("cann't insert same node, found value " + value);
        }

        node.height = Math.max(height(node.left), height(node.right)) + 1;

        return node;
    }

    public void remove(int value) {
        root = remove(root, value);
    }

    private AVLNode remove(AVLNode node, int value) {
        if (node == null) {
            return null;
        }
        if (value < node.value) {
            node.left = remove(node.left, value);
            if (height(node.right) - height(node.left) == 2) {
                if (height(node.right) > height(node.left)) {
                    node = rr(node);
                } else {
                    node = lr(node);
                }
            }
        } else if (value > node.value) {
            node.right = remove(node.right, value);
            if (height(node.left) - height(node.right) == 2) {
                AVLNode leftNode = node.left;
                if (height(leftNode.left) > height(leftNode.right)) {
                    node = ll(node);
                } else {
                    node = rl(node);
                }
            }
        } else if (value == node.value) {
            if (node.left == null || node.right == null) {
                node = node.left != null? node.left: node.right;
            } else if (node.left != null && node.right != null) {
                if (height(node.left) > height(node.right)) {
                    AVLNode leftMaxNode = findMaxNode(node.left);
                    node.value = leftMaxNode.value;
                    node.left = remove(node.left, value);
                } else {
                    AVLNode rightMinNode = findMinNode(node.right);
                    node.value = rightMinNode.value;
                    node.right = remove(node.right, value);
                }
            }
        }
        return node;
    }

    private AVLNode findMinNode(AVLNode node) {
        if (node == null) {
            return null;
        }
        while (node.left != null) {
            node = node.left;
        }
        return node;
    }

    private AVLNode findMaxNode(AVLNode node){
        if (node == null) {
            return null;
        }
        while (node.right != null) {
            node = node.right;
        }
        return node;
    }

    public boolean isBinarySearchTree() {
        return isBinarySearchTree(root, Integer.MIN_VALUE);
    }

    private boolean isBinarySearchTree(AVLNode node, int last) {
        if (node == null) {
            return true;
        }
        if (!isBinarySearchTree(node.left, last)) {
            return false;
        }
        if (node.value < last) {
            return false;
        }
        last = node.value;
        if (!isBinarySearchTree(node.right, last)) {
            return false;
        }
        return true;
    }

    static class LinkedListNode {
        public int value;
        public LinkedListNode prev;
        public LinkedListNode next;

        public LinkedListNode() { }

        public LinkedListNode(int value) {
            this.value = value;
        }

        public LinkedListNode(int value, LinkedListNode prev, LinkedListNode next) {
            this.value = value;
            this.prev = prev;
            this.next = next;
        }

        public static LinkedListNode getHeader(LinkedListNode node) {
            if (node == null) {
                return null;
            }
            LinkedListNode cursor = node;
            while (cursor != null && cursor.prev != null) {
                cursor = cursor.prev;
            }
            return cursor;
        }

        // 获得中间节点
        public static LinkedListNode getMiddleNode(LinkedListNode header) {
            if (header == null) {
                return null;
            }
            LinkedListNode step1 = header;
            LinkedListNode step2 = header;
            while (step2 != null && step2.next != null) {
                step1 = step1.next;
                step2 = step2.next.next;
            }
            return step1;
        }

        public String toString() {
            return "[LinkedListNode value=" + value + ", prev = " + (prev == null? null: prev.value) + ", next=" + (next == null? null: next.value) + "]";
        }
    }

    /**
     * BST转双向循环链表
     * @return
     */
    public AVLTree.LinkedListNode toLinkedList() {
        return toLinkedList(root);
    }

    public AVLTree.LinkedListNode toLinkedList(AVLNode node) {
        if (node == null) {
            return null;
        }
        AVLTree.LinkedListNode header = new AVLTree.LinkedListNode();
        AVLTree.LinkedListNode tail = header;
        AVLTree.LinkedListNode start = header;
        Stack<AVLNode> stack = new Stack<>();
        AVLNode cursor = node;
        while (true) {
            while (cursor != null) {
                stack.push(cursor);
                cursor = cursor.left;
            }
            if (stack.isEmpty()) {
                break;
            }
            cursor = stack.pop();
            // create linked node
            tail.next = new LinkedListNode(cursor.value);
            header = tail;
            tail = tail.next;
            tail.prev = header;
            // create linked node end
            cursor = cursor.right;
        }
        // 向前移动一次,处理空节点
        start = start.next;
        // 代码走到这里,tail已经形成了双向链表,但不是循环的,所以这里要将头尾闭环
        tail.next = start;
        start.prev = tail;
        // 返回第一个节点
        return start;
    }

    public void inOrder() {
        inOrder(root);
    }

    private void inOrder(AVLNode node) {
        AVLNode cursor = node;
        Stack<AVLNode> stack = new Stack<>();
        while (true) {
            while (cursor != null) {
                stack.push(cursor);
                cursor = cursor.left;
            }
            if (stack.isEmpty()) {
                break;
            }
            cursor = stack.pop();
            System.out.println(cursor);
            cursor = cursor.right;
        }
    }

    public void preOrder() {
        preOrder(root);
    }

    public void preOrder(AVLNode node) {
        AVLNode cursor = node;
        Stack<AVLNode> stack = new Stack<>();
        while (true) {
            while (cursor != null) {
                System.out.print(cursor.value + " ");
                stack.push(cursor);
                cursor = cursor.left;
            }
            if (stack.isEmpty()) {
                break;
            }
            cursor = stack.pop();
            cursor = cursor.right;
        }
        System.out.println();
    }

    public AVLNode findSmallestN(int num) {
        return findSmallestN(root, num, 0);
    }

    private AVLNode findSmallestN(AVLNode node, int n, int count) {
        if (node == null) {
            return null;
        }
        AVLNode left = findSmallestN(node.left, n, count);
        if (left != null) {
            return left;
        }
        if (++count == n) {
            return node;
        }
        return  findSmallestN(node.right, n, count);
    }

    // 找到第N小的树
    private AVLNode findSmallestN(AVLNode node, int n) {
        if (node == null) {
            return null;
        }
        Stack<AVLNode> stack = new Stack<>();
        AVLNode cursor = node;
        while (true) {
            while (cursor != null) {
                stack.push(cursor);
                cursor = cursor.left;
            }
            if (stack.isEmpty()) {
                break;
            }
            cursor = stack.pop();
            if (--n == 0) {
                return cursor;
            }
            cursor = cursor.right;
        }
        return null;
    }

    public static void main(String args[]) {

        int arr[] = {3, 2, 1, 4, 5, 6, 7, 16, 15, 14, 13, 12, 11, 10, 8, 9, 17};
        AVLTree tree = new AVLTree();
        for (int i = 0; i < arr.length; i++) {
            tree.insert(arr[i]);
        }
        // tree.inOrder();
        AVLTree.LinkedListNode linkedListNode = tree.toLinkedList();
        AVLTree tree2 = new AVLTree(linkedListNode);
        // tree2.inOrder();
        System.out.println(tree2.findSmallestN(3));
        // System.out.println(tree.isBinarySearchTree());
    }
}
