package com.exam.tree;

public class TreeUtils {

    static Node buildTree() {
        Node left = new Node(2, new Node(4), new Node(5));
        Node right = new Node(3, new Node(6), new Node(7));
        return new Node(1, left, right);
    }

    static Node buildTree2() {
        Node left = new Node(2, new Node(4, new Node(8), new Node(9)), new Node(5));
        Node right = new Node(3, new Node(6), new Node(7));
        return new Node(1, left, right);
    }

    static Node buildTree3() {
        Node left = new Node(2, new Node(4, new Node(8), new Node(9)), new Node(5, new Node(10), new Node(11)));
        Node right = new Node(3, new Node(6, new Node(12), new Node(13)), new Node(7, new Node(14), new Node(15)));
        return new Node(1, left, right);
    }

    static Node buildBST() {
        Node left = new Node(50, new Node(10, new Node(8), new Node(33)), new Node(80, new Node(66), new Node(88)));
        Node right = new Node(200, new Node(141, new Node(132), new Node(167)), new Node(231, new Node(221), new Node(321)));
        return new Node(100, left, right);
    }
}
