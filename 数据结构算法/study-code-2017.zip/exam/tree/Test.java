package com.exam.tree;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

/**
 * 二叉树基本练习
 */
public class Test {
    // 前序遍历DLR
    static void preOrder(Node node) {
        if (node != null) {
            System.out.println(node.value);
            preOrder(node.left);
            preOrder(node.right);
        }
    }

    // DLR非递归遍历
    static void preOrder2(Node node) {
        Node cursor = node;
        Stack<Node> stack = new Stack<>();
        while (true) {
            while (cursor != null) {
                System.out.println(cursor.value);
                stack.push(cursor);
                cursor = cursor.left;
            }
            if (stack.isEmpty()) {
                break;
            }
            cursor = stack.pop();
            cursor = cursor.right;
        }
    }

    // 中序遍历LDR
    static void midOrder(Node node) {
        if (node != null) {
            midOrder(node.left);
            System.out.println(node.value);
            midOrder(node.right);
        }
    }

    // 中序遍历LDR(非递归)
    static void midOrder2(Node node) {
        Node cursor = node;
        Stack<Node> stack = new Stack<>();
        while (true) {
            while (cursor != null) {
                stack.push(cursor);
                cursor = cursor.left;
            }
            if (stack.isEmpty()) {
                break;
            }
            cursor = stack.pop();
            System.out.println(cursor.value);
            cursor = cursor.right;
        }
    }

    // 后序遍历LRD
    static void postOrder(Node node) {
        if (node != null) {
            postOrder(node.left);
            postOrder(node.right);
            System.out.println(node.value);
        }
    }

    static void postOrder2(Node node) {
        // TODO 非递归
    }

    // 层次遍历(从上向下)
    static void levelOrder(Node node) {
        // TODO 递归
    }

    static void levelOrder2(Node node) {
        Node cursor = node;
        Queue<Node> queue = new LinkedList<>();
        queue.offer(cursor);
        while (!queue.isEmpty()) {
            cursor = queue.poll();
            System.out.println(cursor.value);
            if (cursor.left != null) {
                queue.offer(cursor.left);
            }
            if (cursor.right != null) {
                queue.offer(cursor.right);
            }
        }
    }

    // 层次倒序遍历(从下向上)
    static void descLevelOrder(Node node) {
        // TODO 递归
    }

    static void descLevelOrder2(Node node) {
        Node cursor = node;
        Queue<Node> queue = new LinkedList<>();
        Stack<Node> stack = new Stack<>();
        queue.offer(cursor);
        while (!queue.isEmpty()) {
            cursor = queue.poll();
            stack.push(cursor);
            if (cursor.left != null) {
                queue.offer(cursor.left);
            }
            if (cursor.right != null) {
                queue.offer(cursor.right);
            }
        }
        while (!stack.isEmpty()) {
            System.out.println(stack.pop().value);
        }
    }

    // 找到最大值
    static int findMaxValue(Node node) {
        if (node == null) {
            return Integer.MIN_VALUE;
        }
        return Math.max(node.value, Math.max(findMaxValue(node.left), findMaxValue(node.right)));
    }

    static int findMaxValue2(Node node) {
        // 非递归
        int max = 0;
        Node cursor = node;
        Stack<Node> stack = new Stack<>();
        while (true) {
            while (cursor != null) {
                max = Math.max(max, cursor.value);
                stack.push(cursor);
                cursor = cursor.left;
            }
            if (stack.isEmpty()) {
                break;
            }
            cursor = stack.pop();
            cursor = cursor.right;
        }
        return max;
    }

    // 求树的高度
    static int height(Node node) {
        // 递归
        if (node == null) {
            return 0;
        }
        return Math.max(height(node.left), height(node.right)) + 1;
    }

    static int height2(Node node) {
        if (node == null) {
            return 0;
        }
        // 非递归
        int height = 0;
        Queue<Node> queue = new LinkedList<>();
        queue.offer(node);
        int length = queue.size();
        while (!queue.isEmpty()) {
            Node cursor = queue.poll();
            length--;
            if (cursor.left != null) {
                queue.offer(cursor.left);
            }
            if (cursor.right != null) {
                queue.offer(cursor.right);
            }
            if (length == 0) {
                height++;
                length = queue.size();
            }
        }
        return height;
    }

    // 求树的宽度
    static int width(Node node) {
        // TODO 递归
        return 0;
    }

    static int width2(Node node) {
        Queue<Node> queue = new LinkedList<>();
        queue.offer(node);
        int length = queue.size();
        int maxWidth = 1;
        while (!queue.isEmpty()) {
            Node cursor = queue.poll();
            length--;
            if (cursor.left != null) {
                queue.offer(cursor.left);
            }
            if (cursor.right != null) {
                queue.offer(cursor.right);
            }
            if (length == 0) {
                length = queue.size();
                maxWidth = Math.max(maxWidth, length);
            }
        }
        return maxWidth;
    }

    // 查找最深的子节点
    static Node findDeepestNode(Node node) {
        // TODO 递归
        return null;
    }

    static Node findDeepestNode2(Node node) {
        // 非递归
        Node deepestNode = node;
        Queue<Node> queue = new LinkedList<>();
        queue.offer(node);
        while (!queue.isEmpty()) {
            Node cursor = queue.poll();
            deepestNode = cursor;
            if (cursor.left != null) {
                queue.offer(cursor.left);
            }
            if (cursor.right != null) {
                queue.offer(cursor.right);
            }
        }
        return deepestNode;
    }

    // 统计叶子节点个数
    static int leafCount(Node node) {
        if (node == null) {
            return 0;
        } else if (node.left == null && node.right == null) {
            return 1;
        }
        return leafCount(node.left) + leafCount(node.right);
    }

    static int leafCount2(Node node) {
        int leafCount = 0;
        Stack<Node> stack = new Stack<>();
        Node cursor = node;
        while (true) {
            while (cursor != null) {
                if (cursor.left == null && cursor.right == null) {
                    leafCount++;
                }
                stack.push(cursor);
                cursor = cursor.left;
            }
            if (stack.isEmpty()) {
                break;
            }
            cursor = stack.pop();
            cursor = cursor.right;
        }
        return leafCount;
    }

    // 判断两个tree是否完全一样
    static boolean isSame(Node node1, Node node2) {
        if ((node1 == null && node2 != null) || (node1 != null && node2 == null)) {
            return false;
        } else if (node1 == null && node2 == null) {
            return true;
        } else if (node1.value != node2.value) {
            return false;
        }
        if (isSame(node1.left, node2.left)) {
            return isSame(node1.right, node2.right);
        } else {
            return false;
        }
    }

    static boolean isSame2(Node node1, Node node2) {
        // TODO 非递归(采用中序遍历)
        return true;
    }

    // 计算所有节点值总和
    static int sumTreeValue(Node node) {
        if (node == null) {
            return 0;
        }
        return sumTreeValue(node.left) + sumTreeValue(node.right) + node.value;
    }

    static int sumTreeValue2(Node node) {
        // 非递归
        int sum = 0;
        Stack<Node> stack = new Stack<>();
        Node cursor = node;
        while (true) {
            while (cursor != null) {
                sum += cursor.value;
                stack.push(cursor);
                cursor = cursor.left;
            }
            if (stack.isEmpty()) {
                break;
            }
            cursor = stack.pop();
            cursor = cursor.right;
        }
        return sum;
    }

    // 找出同层节点和最大的层
    static int findMaxLevel(Node node) {
        // TODO 递归
        return 0;
    }

    static int findMaxLevel2(Node node) {
        // 非递归
        Node cursor = node;
        Queue<Node> queue = new LinkedList<>();
        queue.offer(node);
        int maxLevel = 1;
        int currentLevel = 1;
        int maxLevelNodeCount = 1;
        int length = queue.size();
        while (!queue.isEmpty()) {
            cursor = queue.poll();
            length--;
            if (cursor.left != null) {
                queue.offer(cursor.left);
            }
            if (cursor.right != null) {
                queue.offer(cursor.right);
            }
            if (length == 0) {
                // reach next level
                length = queue.size();
                currentLevel++;
                if (length > maxLevelNodeCount) {
                    maxLevel = currentLevel;
                    maxLevelNodeCount = length;
                    System.out.println("第" + currentLevel + "有" + length + "个节点");
                }
            }
        }

        return maxLevel;
    }

    // 输出根节点到所有节点的路径
    static void printRoot2NodePath(Node node) {
        printRoot2NodePath(node, new LinkedList<>());
    }

    static void printRoot2NodePath(Node node, Queue<Node> path) {
        // 递归输出全路径
        if (node == null) {
            return;
        }
        path.offer(node);
        Queue<Node> clonePath = new LinkedList<>(path);
        Queue<Node> clonePath2 = new LinkedList<>(path);

        printRoot2NodePath(node.left, clonePath);
        printRoot2NodePath(node.right, clonePath2);

        while (!path.isEmpty()) {
            System.out.print(path.poll().value + "->");
        }
        System.out.println();
    }

    // 非递归方式输出全路径
    static void printRoot2NodePath2(Node node) {
        Node cursor = node;
        Stack<Node> stack = new Stack<>();
        Queue<Node> path = new LinkedList<>();
        while (true) {
            while (cursor != null) {
                stack.push(cursor);
                path.offer(cursor);
                print(cursor, path);
                cursor = cursor.left;
            }
            if (stack.isEmpty()) {
                break;
            }
            cursor = stack.pop();
            if (cursor.right == null) {
                ((LinkedList) path).removeLast();
            }
            cursor = cursor.right;
        }
    }

    static void print(Node node, Queue<Node> path) {
        Queue<Node> pathClone = new LinkedList<>(path);
        for (Node n : pathClone) {
            System.out.print(n.value + " -> ");
        }
        System.out.println();
    }

    // 给定一个expect值,判断是否存在一个路径value之和等于这个expect的节点
    // 获得二叉树第N层的节点数
    static int findNLevelNodeCount(Node node, int level) {
        if (node == null) {
            return 0;
        } else if (level == 1) {
            return 1;
        }
        return findNLevelNodeCount(node.left, level - 1) + findNLevelNodeCount(node.right, level - 1);
    }

    // 生成镜像树
    static Node genMirrorTree(Node node) {
        Node mirror = null;
        if (node != null) {
            mirror = new Node(node.value);
            mirror.right = genMirrorTree(node.left);
            mirror.left = genMirrorTree(node.right);
        }
        return mirror;
    }

    // 判断2个二叉树是否互为镜像
    static boolean isMirrorTree(Node node, Node leakMirror) {
        if (node == null && leakMirror == null) {
            return true;
        } else if (node.value != leakMirror.value) {
            return false;
        }
        return isMirrorTree(node.left, leakMirror.right) && isMirrorTree(node.right, leakMirror.left);
    }

    // 根据中序遍历和先序遍历生成二叉树
    static Node generateTreeByPreAndMidOrder(int[] preOrder, int[] midOrder) {
        if (midOrder == null || midOrder.length == 0) {
            return null;
        } else if (midOrder.length == 1) {
            // 4.递归退出条件
            return new Node(midOrder[0]);
        }

        // 1.根据先序找到root
        Node root = new Node(preOrder[0]);

        // 2.根据中序区分出左子树和右子树
        int midIndex = 0;
        int i = 0;
        for (; i < midOrder.length; i++) {
            if (midOrder[i] == root.value) {
                midIndex = i;
                break;
            }
        }

        // 3.将非空的子树继续上面的1.2递归操作
        root.left = generateTreeByPreAndMidOrder(Arrays.copyOfRange(preOrder, 1, i + 1), Arrays.copyOfRange(midOrder, 0, midIndex));
        root.right = generateTreeByPreAndMidOrder(Arrays.copyOfRange(preOrder, i + 1, preOrder.length), Arrays.copyOfRange(midOrder, midIndex + 1, midOrder.length));

        return root;
    }

    // 根据中序遍历和层级遍历,构建二叉树
    static Node genTreeByMidAndLevelOrder(int[] midOrder, int[] levelorder) {
        // TODO
        return null;
    }

    // 打印出节点之为n的所有父节点
    static boolean printAllParentNode(Node node, int val) {
        if (node == null) {
            return false;
        } else if (node.value == val || printAllParentNode(node.left, val) || printAllParentNode(node.right, val)) {
            System.out.println(node.value);
            return true;
        }
        return false;
    }

    // 找到2个节点最近的公共祖先(LCA)
    static Node findPublicParentNode(Node root, int val1, int val2) {

        if (root == null) {
            return null;
        } else if (val1 == root.value || val2 == root.value) {
            return root;
        }

        Node l = findPublicParentNode(root.left, val1, val2);
        Node r = findPublicParentNode(root.right, val1, val2);

        if (l != null && r != null) {
            return root;
        } else {
            return l != null ? l : r;
        }
    }

    // zigZag遍历:1 3 2 4 5 6 7
    static void zigZagOrder(Node node) {
        if (node == null) {
            return;
        }
        boolean flag = true;
        Stack<Node> current = new Stack<>();
        current.push(node);
        Stack<Node> stack = new Stack<>();
        while (!current.isEmpty()) {
            Node temp = current.pop();
            System.out.println(temp.value);
            if (flag) {
                if (temp.left != null) {
                    stack.push(temp.left);
                }
                if (temp.right != null) {
                    stack.push(temp.right);
                }
            } else {
                if (temp.right != null) {
                    stack.push(temp.right);
                }
                if (temp.left != null) {
                    stack.push(temp.left);
                }
            }
            if (current.isEmpty()) {
                flag = !flag;
                current = stack;
                stack = new Stack<>();
            }
        }
    }

    public static void main(String args[]) {
        Node node = TreeUtils.buildTree();
        // Node mirror = new Node();
        // mirror = genMirrorTree(node);
        /// System.out.println(isMirrorTree(node, mirror));
        //int[] preOrder = new int[]{1, 2, 4, 5, 3, 6, 7};
        //int[] midOrder = new int[]{4, 2, 5, 1, 6, 3, 7};
        // Node root = generateTreeByPreAndMidOrder(preOrder, midOrder);
        zigZagOrder(node);
    }
}

