package com.exp;

import java.util.Stack;

/**
 * Created by qudian on 2017/8/1.
 */
public class Tree {
    static class TreeNode {
        public Object value;
        public com.exp.Tree.TreeNode left;
        public com.exp.Tree.TreeNode right;

        public TreeNode() {
        }

        public TreeNode(Object value, com.exp.Tree.TreeNode left, com.exp.Tree.TreeNode right) {
            this.value = value;
            this.left = left;
            this.right = right;
        }
    }

    static com.exp.Tree.TreeNode buildTree() {
        com.exp.Tree.TreeNode left = new com.exp.Tree.TreeNode(2, new com.exp.Tree.TreeNode(4, null, null), new com.exp.Tree.TreeNode(5, null, null));
        com.exp.Tree.TreeNode right = new com.exp.Tree.TreeNode(3, new com.exp.Tree.TreeNode(6, null, null), new com.exp.Tree.TreeNode(7, null, null));
        return new com.exp.Tree.TreeNode(1, left, right);
    }

    static void preOrder(TreeNode cursor) {
        Stack<TreeNode> stack = new Stack<>();
        while (true) {
            while (cursor != null) {
                System.out.println(cursor.value);
                stack.push(cursor);
                cursor = cursor.left;
            }
            if (stack.isEmpty()) {
                break;
            }
            cursor = stack.pop();
            cursor = cursor.right;
        }
    }

    static void middleOrder(TreeNode node) {
        Stack<TreeNode> stack = new Stack<>();
        while (true) {
            while (node != null) {
                stack.push(node);
                node = node.left;
            }
            if (stack.isEmpty()) {
                break;
            }
            node = stack.pop();
            System.out.println(node.value);
            node = node.right;
        }
    }

    static void LrdOrder(TreeNode node) {
        Stack<TreeNode> stack = new Stack<>();
        while(true) {
            while (node != null) {
                stack.push(node);
                node = node.left;
            }
            if (stack.isEmpty()) {
                break;
            }
            node = stack.pop();
            System.out.println(node.value);
        }
    }

    public static void main(String args[]) {
        middleOrder(buildTree());
    }
}
