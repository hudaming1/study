package com.study.graph;

import java.util.LinkedList;
import java.util.Queue;

/**
 * 十字链表存储稀疏图
 */
public class Test3 {

    static class Vertex {
        public char label;
        public boolean isVisited = false;
        public Arc in;
        public Arc out;
        public Vertex(char c) {
            this.label = c;
        }
    }

    static class Arc {
        public int head;
        public int tail;
        public Arc inNext;
        public Arc outNext;

        public Arc(int head, int tail) {
            this.head = head;
            this.tail = tail;
        }
    }

    static class Graph {
        private int count;
        public Test3.Vertex[] vertexs;
        public Graph(int count) {
            vertexs = new Test3.Vertex[count];
        }

        public void addVertex(char c) {
            vertexs[count ++] = new Vertex(c);
        }

        public void addArc(int src, int dest) {
            Arc arc = new Arc(src, dest);
            if (vertexs[src].out == null) {
                vertexs[src].out = arc;
            } else {
                Arc out = vertexs[src].out;
                while (out != null) {
                    if (out.outNext == null) {
                        out.outNext = arc;
                        break;
                    }
                    out = out.outNext;
                }
            }
            if (vertexs[dest].in == null) {
                vertexs[dest].in = arc;
            } else {
                Arc in = vertexs[dest].in;
                while (in != null) {
                    if (in.inNext == null) {
                        in.inNext = arc;
                        break;
                    }
                    in = in.inNext;
                }
            }
        }

        public void dfs() {
            clearVisited();
            dfs(0);
        }

        public void dfs(int index) {
            displayVertex(index);
            vertexs[index].isVisited = true;
            int next = -1;
            while ((next = findUnVisitedNeighbour(index)) != -1) {
                dfs(next);
            }
        }

        public void bfs() {
            Queue<Integer> queue = new LinkedList<>();
            queue.offer(0);
            vertexs[0].isVisited = true;
            while (!queue.isEmpty()) {
                int v = queue.poll();
                displayVertex(v);
                int neighbour = -1;
                while ((neighbour = findUnVisitedNeighbour(v)) != -1) {
                    queue.offer(neighbour);
                    vertexs[neighbour].isVisited = true;
                }
            }
        }

        private int findUnVisitedNeighbour(int v) {
            Arc cursor = vertexs[v].out;
            while (cursor != null) {
                if (vertexs[cursor.tail].isVisited == false) {
                    return cursor.tail;
                }
                cursor = cursor.outNext;
            }
            return -1;
        }

        public void displayVertex(int index) {
            System.out.println(vertexs[index].label);
        }

        private void clearVisited() {
            for (int i = 0 ;i < count;i ++) {
                vertexs[i].isVisited = false;
            }
        }
    }

    public static void main(String args[]) {
        Test3.Graph graph = new Graph(6);
        graph.addVertex('A');
        graph.addVertex('B');
        graph.addVertex('C');
        graph.addVertex('D');
        graph.addVertex('E');
        graph.addVertex('F');

        graph.addArc(0, 1);
        graph.addArc(0, 2);
        graph.addArc(0, 5);
        graph.addArc(2, 3);
        graph.addArc(3, 1);
        graph.addArc(3, 2);
        graph.addArc(2, 1);
        graph.addArc(2, 1);
        graph.addArc(2, 4);

        graph.bfs();
    }
}
