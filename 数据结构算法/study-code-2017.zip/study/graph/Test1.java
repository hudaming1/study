package com.study.graph;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

/**
 * 邻接矩阵 图结构
 */
public class Test1 {

    static class Vertex {
        public char label;
        public boolean visited;

        public Vertex(char lab) {
            this.label = lab;
            visited = false;
        }

        public String toString() {
            return "Vertex [" + label + ", " + visited + "]";
        }
    }

    static class Graph {
        private final int maxVertices = 20;
        private Vertex vertexList[];
        private int adjMatrix[][];
        private int vertexCount;

        public Graph() {
            vertexList = new Vertex[maxVertices];
            adjMatrix = new int[maxVertices][maxVertices];
            vertexCount = 0;
            for (int y = 0; y < maxVertices; y++) {
                for (int x = 0; x < maxVertices; x++) {
                    adjMatrix[x][y] = 0;
                }
            }
        }

        /**
         * 添加定点
         */
        public void addVertex(char lab) {
            vertexList[vertexCount++] = new Vertex(lab);
        }

        /**
         * 添加一条边(无向图)
         */
        public void addEdge(int start, int end) {
            adjMatrix[start][end] = 1;
            adjMatrix[end][start] = 1;
        }

        public void displayVertex(int v) {
            System.out.println(vertexList[v].label);
        }

        /**
         * 深度优先搜索,非递归方式
         */
        public void dfs() {
            Stack<Integer> stack = new Stack<>();
            displayVertex(0);
            vertexList[0].visited = true;
            stack.push(0);
            while (!stack.isEmpty()) {
                int neighbour = findUnVisitNeighbour(stack.peek());
                if (neighbour == -1) {
                    stack.pop();
                } else {
                    displayVertex(neighbour);
                    vertexList[neighbour].visited = true;
                    stack.push(neighbour);
                }
            }
            clearVisited();
        }

        private void clearVisited() {
            for (int i = 0 ;i < vertexCount;i ++) {
                vertexList[i].visited = false;
            }
        }

        /**
         * 深度优先搜索,递归遍历
         */
        public void dfsRecursion() {
            dfsRecursion(0);
            clearVisited();
        }

        private void dfsRecursion(int v) {
            displayVertex(v);
            vertexList[v].visited = true;
            while (true) {
                int neighbour = findUnVisitNeighbour(v);
                if (neighbour == -1) {
                    break;
                }
                dfsRecursion(neighbour);
            }
        }

        /**
         * 获得节点v(索引下标)临近未访问过的节点(索引下标)
         * @return
         */
        private int findUnVisitNeighbour(int v) {
            for (int i = 0 ;i < vertexCount;i ++) {
                if (adjMatrix[v][i] == 1 && vertexList[i].visited == false) {
                    return i;
                }
            }
            return -1;
        }

        /**
         * 广度优先搜索,非递归方式
         */
        public void bfs() {
            Queue<Integer> queue = new LinkedList<>();
            queue.offer(0);
            vertexList[0].visited = true;
            int l = queue.size();
            while (!queue.isEmpty()) {
                int v = queue.poll();
                displayVertex(v);
                int neighbour = -1;
                while ((neighbour = findUnVisitNeighbour(v))!= -1) {
                    queue.offer(neighbour);
                    vertexList[neighbour].visited = true;
                }
            }
        }
    }

    public static void main(String args[]) {
        Graph graph = new Graph();
        graph.addVertex('A');
        graph.addVertex('B');
        graph.addVertex('C');
        graph.addVertex('D');
        graph.addVertex('E');
        graph.addVertex('F');
        graph.addVertex('G');
        graph.addVertex('H');
        graph.addEdge(0, 1);
        graph.addEdge(1, 2);
        graph.addEdge(1, 7);
        graph.addEdge(2, 3);
        graph.addEdge(2, 4);
        graph.addEdge(4, 5);
        graph.addEdge(4, 6);
        graph.addEdge(4, 7);
        graph.bfs();
    }
}
