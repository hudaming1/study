package com.study.graph;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 邻接矩阵 网结构
 */
public class Test1_1 {
    static class Vertex {
        public char label;
        public Vertex(char c) {
            this.label = c;
        }
    }

    static class Graph {
        private int count;
        public Test1_1.Vertex[] vertexs;
        public int[][] edges;

        public Graph(int count) {
            vertexs = new Vertex[count];
            edges = new int[count][count];
        }

        public void addVertex(char c) {
            vertexs[count++] = new Vertex(c);
        }

        public void addEdge(int src, int dest, int weight) {
            edges[src][dest] = weight;
        }

        static class Edge {
            public int src;
            public int dest;
            public int weight;

            public Edge(int src, int dest, int weight) {
                this.src = src;
                this.dest = dest;
                this.weight = weight;
            }

            @Override
            public boolean equals(Object _edge) {
                if (!(_edge instanceof Edge)) {
                    return false;
                } else if (_edge == this) {
                    return true;
                }
                Edge edge = (Edge) _edge;
                return edge.src == src && edge.dest == dest && edge.weight == weight;
            }

            @Override
            public int hashCode() {
                return (src + "|" + dest + "|" + weight).hashCode();
            }

            @Override
            public String toString() {
                return "Edge [src=" + src + ", dest=" + dest + ", weight=" + weight + "]";
            }
        }

        public List<Edge> minGenTreePrim() {
            List<Integer> selectedVertex = new ArrayList<>();
            List<Edge> selectEdges = new ArrayList<>();
            List<Edge> waitSelectEdges = new ArrayList<>();
            int cursor = 0;
            selectedVertex.add(cursor);

            while (selectedVertex.size() < count) {
                List<Edge> neighbourEdges = findNeighbourEdges(cursor);
                waitSelectEdges.addAll(neighbourEdges);

                label1:
                while (true) {
                    Edge minEdge = findMinWeightEdge(waitSelectEdges);
                    if (!selectedVertex.contains(minEdge.src) || !selectedVertex.contains(minEdge.dest)) {
                        cursor = !selectedVertex.contains(minEdge.src) ? minEdge.src : minEdge.dest;
                        selectEdges.add(minEdge);
                        selectedVertex.add(cursor);
                        break label1;
                    }
                    waitSelectEdges.remove(minEdge);
                }
            }
            return selectEdges;
        }

        private Edge findMinWeightEdge(List<Edge> edges) {
            if (edges == null || edges.isEmpty()) {
                return null;
            } else if (edges.size() == 1) {
                return edges.get(0);
            }
            Edge minEdge = edges.get(0);
            for (Edge edge : edges) {
                if (edge.weight < minEdge.weight) {
                    minEdge = edge;
                }
            }
            return minEdge;
        }

        private List<Edge> findNeighbourEdges(int v) {
            List<Edge> list = new ArrayList<>();
            for (int i = 0; i < count; i++) {
                if (edges[v][i] > 0) {
                    list.add(new Edge(v, i, edges[v][i]));
                }
            }
            for (int i = 0; i < count; i++) {
                if (edges[i][v] > 0) {
                    list.add(new Edge(i, v, edges[i][v]));
                }
            }
            return list;
        }

        private List<Edge> sortEdgeByWeight(int[][] edges) {
            List<Edge> edgeList = new ArrayList<>();

            for (int i = 0; i < edges.length; i++) {
                for (int j = 0; j < edges.length; j++) {
                    if (edges[i][j] > 0) {
                        edgeList.add(new Edge(i, j, edges[i][j]));
                    }
                }
            }

            Collections.sort(edgeList, new Comparator<Edge>() {
                @Override
                public int compare(Edge o1, Edge o2) {
                    if (o1.weight < o2.weight) {
                        return -1;
                    } else if (o1.weight == o2.weight) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            });

            return edgeList;
        }

        static class DisJoinSet {
            private int[] array;

            public DisJoinSet(int num) {
                array = new int[num];
                for (int i = 0 ;i < array.length;i ++) {
                    array[i] = i;
                }
            }

            public int find(int m) {
                while (m != array[m]) {
                    m = array[m];
                }
                return m;
            }

            public void join(int m, int n) {
                array[find(m)] = find(n);
            }
        }
        public List<Edge> minGenTreeKurskal() {
            List<Edge> edges = new ArrayList<>();
            DisJoinSet joinSet = new DisJoinSet(this.edges.length);

            // 1.对边根据权重排序
            List<Edge> sortEdges = sortEdgeByWeight(this.edges);

            // 2.根据排序后的数组建立Edge
            for (Edge edge : sortEdges) {

                int srcRoot = joinSet.find(edge.src);
                int destRoot = joinSet.find(edge.dest);

                // 3.假如起点终点都落在相连的一条边上,则认为相连后会形成闭环
                if (srcRoot == destRoot) {
                    continue;
                }

                joinSet.join(edge.src, edge.dest);
                edges.add(edge);
            }
            return edges;
        }

    }

    public static void main(String args[]) {
        Graph graph = new Graph(8);
        graph.addVertex('A');
        graph.addVertex('B');
        graph.addVertex('C');
        graph.addVertex('D');
        graph.addVertex('E');
        graph.addVertex('F');
        graph.addVertex('G');
        graph.addVertex('H');
        graph.addEdge(0, 1, 1);
        graph.addEdge(0, 7, 5);
        graph.addEdge(1, 2, 3);
        graph.addEdge(1, 7, 5);
        graph.addEdge(2, 3, 1);
        graph.addEdge(2, 4, 3);
        graph.addEdge(4, 5, 2);
        graph.addEdge(4, 6, 1);
        graph.addEdge(1, 5, 1);
        graph.addEdge(7, 3, 4);
        graph.addEdge(5, 6, 3);
        graph.addEdge(0, 5, 1);
        List<Graph.Edge> edges = graph.minGenTreeKurskal();
        for (Graph.Edge edge: edges) {
            System.out.println(edge);
        }
        System.out.println("---------------------------------------");
        List<Graph.Edge> edges2 = graph.minGenTreePrim();
        for (Graph.Edge edge: edges2) {
            System.out.println(edge);
        }
    }
}
