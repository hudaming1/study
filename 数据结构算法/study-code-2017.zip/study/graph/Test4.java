package com.study.graph;

/**
 * 邻接多重表
 */
public class Test4 {
}
