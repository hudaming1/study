package com.study.graph;

import java.util.LinkedList;
import java.util.Queue;

/**
 * 邻接表存储稀疏图
 */
public class Test2 {

    static class Vertex2 {
        public char label;
        public boolean isVisited = false;
        public Edge2 adj;
        public Vertex2(char label) {
            this.label = label;
        }
    }

    static class Edge2 {
        public int index;
        public Edge2 next;
        public Edge2(int index) {
            this.index = index;
        }
    }

    static class Graph2 {
        public int curIndex = 0;
        public Vertex2[] vertexs;

        public Graph2(int count) {
            vertexs = new Vertex2[count];
        }

        public void addVertex(char c) {
            vertexs[curIndex ++] = new Vertex2(c);
        }

        public void addEdge(int src, int dest) {
            Edge2 edge2 = vertexs[src].adj;
            if (edge2 == null) {
                vertexs[src].adj = new Edge2(dest);
                return;
            }
            while (edge2 != null) {
                if (edge2.next == null) {
                    edge2.next = new Edge2(dest);
                    return;
                }
                edge2 = edge2.next;
            }
        }

        public void displayVertex(int index) {
            System.out.println(vertexs[index].label);
        }

        public int findUnVisitedNeighbour(int v) {
            Edge2 edge2 = vertexs[v].adj;
            while (edge2 != null) {
                if (vertexs[edge2.index].isVisited == false) {
                    return edge2.index;
                }
                edge2 = edge2.next;
            }
            return -1;
        }

        private void clearVisited() {
            for (int i = 0 ;i < curIndex;i ++) {
                vertexs[i].isVisited = false;
            }
        }

        public void dfs() {
            clearVisited();
            dfs(0);
        }

        private void dfs(int index) {
            Vertex2 v = vertexs[index];
            v.isVisited = true;
            displayVertex(index);
            Edge2 edge2 = v.adj;
            while (edge2 != null) {
                int neighbour = findUnVisitedNeighbour(index);
                if (neighbour != -1) {
                    dfs(neighbour);
                }
            }
        }

        public void bfs() {
            clearVisited();
            Queue<Integer> queue = new LinkedList<>();
            queue.offer(0);
            vertexs[0].isVisited = true;
            while (!queue.isEmpty()) {
                int v = queue.poll();
                displayVertex(v);
                int neighbour = -1;
                while ((neighbour = findUnVisitedNeighbour(v)) != -1) {
                    queue.offer(neighbour);
                    vertexs[neighbour].isVisited = true;
                }
            }
        }
    }

    public static void main(String args[]) {
        Graph2 graph = new Graph2(8);
        graph.addVertex('A');
        graph.addVertex('B');
        graph.addVertex('C');
        graph.addVertex('D');
        graph.addVertex('E');
        graph.addVertex('F');
        graph.addVertex('G');
        graph.addVertex('H');

        graph.addEdge(0, 1);
        graph.addEdge(1, 2);
        graph.addEdge(1, 7);
        graph.addEdge(2, 3);
        graph.addEdge(2, 4);
        graph.addEdge(4, 5);
        graph.addEdge(4, 6);
        graph.addEdge(4, 7);

        graph.bfs();
    }
}
