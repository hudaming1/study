package com.study.tree;

/**
 * Java 语言: AVL树
 *
 * @author skywang
 * @date 2013/11/07
 */

public class AVLTree<T extends Comparable<T>> {
    private AVLTreeNode<T> mRoot;    // 根结点

    // AVL树的节点(内部类)
    class AVLTreeNode<T extends Comparable<T>> {
        T key;                // 关键字(键值)
        int height;         // 高度
        AVLTreeNode<T> left;    // 左孩子
        AVLTreeNode<T> right;    // 右孩子

        public AVLTreeNode(T key, AVLTreeNode<T> left, AVLTreeNode<T> right) {
            this.key = key;
            this.left = left;
            this.right = right;
            this.height = 0;
        }

        public String toString() {
            return "AVLTreeNoe [key=" + key + ", height=" + height + "]";
        }
    }

    // 构造函数
    public AVLTree() {
        mRoot = null;
    }

    /*
     * 获取树的高度
     */
    private int height(AVLTreeNode<T> tree) {
        if (tree != null)
            return tree.height;

        return 0;
    }

    public int height() {
        return height(mRoot);
    }

    /*
     * 比较两个值的大小
     */
    private int max(int a, int b) {
        return a > b ? a : b;
    }

    /*
     * 前序遍历"AVL树"
     */
    private void preOrder(AVLTreeNode<T> tree) {
        if (tree != null) {
            System.out.print(tree.key + " ");
            preOrder(tree.left);
            preOrder(tree.right);
        }
    }

    public void preOrder() {
        preOrder(mRoot);
    }

    /*
     * 中序遍历"AVL树"
     */
    private void inOrder(AVLTreeNode<T> tree) {
        if (tree != null) {
            inOrder(tree.left);
            System.out.print(tree.key + " ");
            inOrder(tree.right);
        }
    }

    public void inOrder() {
        inOrder(mRoot);
    }

    /*
     * 后序遍历"AVL树"
     */
    private void postOrder(AVLTreeNode<T> tree) {
        if (tree != null) {
            postOrder(tree.left);
            postOrder(tree.right);
            System.out.print(tree.key + " ");
        }
    }

    public void postOrder() {
        postOrder(mRoot);
    }

    /*
     * (递归实现)查找"AVL树x"中键值为key的节点
     */
    private AVLTreeNode<T> search(AVLTreeNode<T> x, T key) {
        if (x == null)
            return x;

        int cmp = key.compareTo(x.key);
        if (cmp < 0)
            return search(x.left, key);
        else if (cmp > 0)
            return search(x.right, key);
        else
            return x;
    }

    public AVLTreeNode<T> search(T key) {
        return search(mRoot, key);
    }

    /*
     * (非递归实现)查找"AVL树x"中键值为key的节点
     */
    private AVLTreeNode<T> iterativeSearch(AVLTreeNode<T> x, T key) {
        while (x != null) {
            int cmp = key.compareTo(x.key);

            if (cmp < 0)
                x = x.left;
            else if (cmp > 0)
                x = x.right;
            else
                return x;
        }

        return x;
    }

    public AVLTreeNode<T> iterativeSearch(T key) {
        return iterativeSearch(mRoot, key);
    }

    /* 
     * 查找最小结点：返回tree为根结点的AVL树的最小结点。
     */
    private AVLTreeNode<T> minimum(AVLTreeNode<T> tree) {
        if (tree == null)
            return null;

        while (tree.left != null)
            tree = tree.left;
        return tree;
    }

    public T minimum() {
        AVLTreeNode<T> p = minimum(mRoot);
        if (p != null)
            return p.key;

        return null;
    }

    /* 
     * 查找最大结点：返回tree为根结点的AVL树的最大结点。
     */
    private AVLTreeNode<T> maximum(AVLTreeNode<T> tree) {
        if (tree == null)
            return null;

        while (tree.right != null)
            tree = tree.right;
        return tree;
    }

    public T maximum() {
        AVLTreeNode<T> p = maximum(mRoot);
        if (p != null)
            return p.key;

        return null;
    }

    /*
     * LL：左左对应的情况(左单旋转)。
     *
     * 返回值：旋转后的根节点
     */
    private AVLTreeNode<T> leftLeftRotation(AVLTreeNode<T> oldRoot) {

        AVLTreeNode<T>  newRoot = oldRoot.left;
        oldRoot.left = newRoot.right;
        newRoot.right = oldRoot;

        oldRoot.height = max(height(oldRoot.left), height(oldRoot.right)) + 1;
        newRoot.height = max(height(newRoot.left), oldRoot.height) + 1;

        return newRoot;
    }

    /*
     * RR：右右对应的情况(右单旋转)。
     *
     * 返回值：旋转后的根节点
     */
    private AVLTreeNode<T> rightRightRotation(AVLTreeNode<T> oldRoot) {
        AVLTreeNode<T> newRoot = oldRoot.right;
        oldRoot.right = newRoot.left;
        newRoot.left = oldRoot;

        oldRoot.height = max(height(oldRoot.left), height(oldRoot.right)) + 1;
        newRoot.height = max(height(newRoot.right), oldRoot.height) + 1;

        return newRoot;
    }

    /*
     * LR：左右对应的情况(左双旋转)。
     *
     * 返回值：旋转后的根节点
     */
    private AVLTreeNode<T> leftRightRotation(AVLTreeNode<T> k3) {
        k3.left = rightRightRotation(k3.left);

        return leftLeftRotation(k3);
    }

    /*
     * RL：右左对应的情况(右双旋转)。
     *
     * 返回值：旋转后的根节点
     */
    private AVLTreeNode<T> rightLeftRotation(AVLTreeNode<T> k1) {
        k1.right = leftLeftRotation(k1.right);

        return rightRightRotation(k1);
    }

    /* 
     * 将结点插入到AVL树中，并返回根节点
     *
     * 参数说明：
     *     tree AVL树的根结点
     *     key 插入的结点的键值
     * 返回值：
     *     根节点
     */
    private AVLTreeNode<T> insert(AVLTreeNode<T> node, T key) {
        if (node == null) {
            // 新建节点
            node = new AVLTreeNode<T>(key, null, null);
            node.height = max(height(node.left), height(node.right)) + 1;
            return node;
        }
        // 1.判断在左/右子树插入新节点
        int cmp = key.compareTo(node.key);

        if (cmp < 0) {
            // 2.将新节点插入到左子树
            node.left = insert(node.left, key);
            // 3.如果插入新节点导致avl失衡,则需要旋转
            if (height(node.left) - height(node.right) == 2) {
                // 3.1如果新节点落在在left.left上,则LL旋转
                if (key.compareTo(node.left.key) < 0)
                    node = leftLeftRotation(node);
                else
                // 3.2如果新节点落在了left.right上,则LR旋转
                    node = leftRightRotation(node);
            }
        } else if (cmp > 0) {    // 应该将key插入到"tree的右子树"的情况
            node.right = insert(node.right, key);
            // 插入节点后，若AVL树失去平衡，则进行相应的调节。
            if (height(node.right) - height(node.left) == 2) {
                if (key.compareTo(node.right.key) > 0)
                    node = rightRightRotation(node);
                else
                    node = rightLeftRotation(node);
            }
        } else {    // cmp==0
            System.out.println("添加失败：不允许添加相同的节点！");
        }

        // 4.当节点下新增节点,且也进行过旋转后,需要重新计算节点高度
        node.height = max(height(node.left), height(node.right)) + 1;

        return node;
    }

    public void insert(T key) {
        mRoot = insert(mRoot, key);
    }

    /* 
     * 删除结点(z)，返回根节点
     *
     * 参数说明：
     *     tree AVL树的根结点
     *     z 待删除的结点
     * 返回值：
     *     根节点
     */
    private AVLTreeNode<T> remove(AVLTreeNode<T> tree, AVLTreeNode<T> z) {
        // 0.如果没有找到要删除的节点,则直接返回null
        if (tree == null || z == null) {
            return null;
        }

        // 1.判断目标删除节点在left还是right上
        int cmp = z.key.compareTo(tree.key);
        if (cmp < 0) {
            // 2.在left上继续寻找删除目标
            tree.left = remove(tree.left, z);
            // 3.如果left删除成功后,判断是否失衡
            if (height(tree.right) - height(tree.left) == 2) {
                // 4.删除left下的节点后,如果引起失衡,一定是因为right过高导致,所以需要调整right子树的平衡
                AVLTreeNode<T> r = tree.right;
                // 5.既然知道了失衡节点,即tree.right,那么下一步就是要判断如何旋转才能达到平衡(具体原因,自己画图看吧)
                if (height(r.left) > height(r.right))
                    tree = rightLeftRotation(tree);
                else
                    tree = rightRightRotation(tree);
            }
        } else if (cmp > 0) {
            tree.right = remove(tree.right, z);
            if (height(tree.left) - height(tree.right) == 2) {
                AVLTreeNode<T> l = tree.left;
                if (height(l.right) > height(l.left))
                    tree = leftRightRotation(tree);
                else
                    tree = leftLeftRotation(tree);
            }
        } else {
            // 这里是cmp == 0,意思是命中目标删除节点
            if ((tree.left != null) && (tree.right != null)) {
                // 如果目标删除节点很"健全"(左右节点双全),那么就比较麻烦了
                // 这里思路是,既然作为root要被删除,这时候要考虑要让谁来继承自己,优先原则是看left和right谁更height
                if (height(tree.left) > height(tree.right)) {
                    // 如果left更高,则在自己的left里找一个最大的value,替代自己即可,这样还能保证不用做任何旋转就能平衡的目的.
                    AVLTreeNode<T> max = maximum(tree.left);
                    tree.key = max.key;
                    // 此时从目标删除节点沿着left到最叶子节点,会出现两个一样的节点,这时需要删除处于最下面的节点.
                    tree.left = remove(tree.left, max);
                } else {
                    AVLTreeNode<T> min = maximum(tree.right);
                    tree.key = min.key;
                    tree.right = remove(tree.right, min);
                }
            } else {
                // 如果目标删除节点有"残缺(只有一个子)",则直接让自己唯一的孩子"上位"替代自己
                tree = (tree.left != null) ? tree.left : tree.right;
            }
        }

        return tree;
    }

    public void remove(T key) {
        AVLTreeNode<T> z;

        if ((z = search(mRoot, key)) != null)
            mRoot = remove(mRoot, z);
    }

    /* 
     * 销毁AVL树
     */
    private void destroy(AVLTreeNode<T> tree) {
        if (tree == null)
            return;

        if (tree.left != null)
            destroy(tree.left);
        if (tree.right != null)
            destroy(tree.right);

        tree = null;
    }

    public void destroy() {
        destroy(mRoot);
    }

    /*
     * 打印"二叉查找树"
     *
     * key        -- 节点的键值 
     * direction  --  0，表示该节点是根节点;
     *               -1，表示该节点是它的父结点的左孩子;
     *                1，表示该节点是它的父结点的右孩子。
     */
    private void print(AVLTreeNode<T> tree, T key, int direction) {
        if (tree != null) {
            if (direction == 0)    // tree是根节点
                System.out.printf("%2d is root\n", tree.key, key);
            else                // tree是分支节点
                System.out.printf("%2d is %2d's %6s child\n", tree.key, key, direction == 1 ? "right" : "left");

            print(tree.left, tree.key, -1);
            print(tree.right, tree.key, 1);
        }
    }

    public void print() {
        if (mRoot != null)
            print(mRoot, mRoot.key, 0);
    }


    public static void main(String[] args) {
        int arr[] = {3, 2, 1, 4, 5, 6, 7, 16, 15, 14, 13, 12, 11, 10, 8, 9};
        int i;
        AVLTree<Integer> tree = new AVLTree<Integer>();

        System.out.printf("== 依次添加: ");
        for (i = 0; i < arr.length; i++) {
            System.out.printf("%d ", arr[i]);
            tree.insert(arr[i]);
        }

        System.out.printf("\n== 前序遍历: ");
        tree.preOrder();

        System.out.printf("\n== 中序遍历: ");
        tree.inOrder();

        System.out.printf("\n== 后序遍历: ");
        tree.postOrder();
        System.out.printf("\n");

        System.out.printf("== 高度: %d\n", tree.height());
        System.out.printf("== 最小值: %d\n", tree.minimum());
        System.out.printf("== 最大值: %d\n", tree.maximum());
        System.out.printf("== 树的详细信息: \n");
        tree.print();

        tree.remove(8);
        tree.remove(13);
        tree.remove(3);
        tree.preOrder();

//        System.out.printf("\n== 高度: %d", tree.height());
//        System.out.printf("\n== 中序遍历: ");
//        tree.inOrder();
//        System.out.printf("\n== 树的详细信息: \n");
//        tree.print();
//
//        // 销毁二叉树
//        tree.destroy();
    }
}