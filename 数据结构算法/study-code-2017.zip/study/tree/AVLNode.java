package com.study.tree;

import com.exam.tree.Node;

/**
 * Created by qudian on 2017/8/8.
 */
class AvlNode extends Node {
    public int height;

    public AvlNode() {
    }

    public AvlNode(Integer value) {
        this(value, null, null);
    }

    public AvlNode(Integer value, AvlNode left, AvlNode right) {
        this.value = value;
        this.left = left;
        this.right = right;
    }

    public String toString() {
        return "[Node value=" + value + ", height=" + height + "]";
    }
}
