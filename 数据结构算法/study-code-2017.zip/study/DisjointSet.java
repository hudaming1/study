package com.study;

import java.util.Arrays;

public class DisjointSet {
    int[] set;
    public DisjointSet(int size) {
        set = new int[size];
        for (int i = 0 ;i < size ;i ++) {
            set[i] = i; // set parents is self
        }
    }

    public int find(int x) {
        if (set[x] == x) {
            return x;
        }
        return set[x] = find(set[x]); // 路径压缩
    }

    public void union(int x, int y) {
        // find x.root
        int xp = find(x);
        // find y.root
        int yp = find(y);
        // set x.root = y
        set[xp] = yp;
    }

    public static void main(String args[]) {
        DisjointSet set = new DisjointSet(10);
        set.union(5, 6);
        set.union(1, 2);
        set.union(0, 2);
        set.union(0, 6);
        System.out.println(Arrays.toString(set.set));
    }
}
